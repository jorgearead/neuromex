<div class="col-12 infor contenido-informacion">
    <h1>Membresias Neuromex</h1>
</div>
<section id="call-to-action" class="wow fadeIn">
    <div class="container text-center">
        <h3>¿Cuáles son los beneficios que tendrás con nuestra membresía?</h3>
        <p>¿Cuáles son los beneficios que tendrás con nuestra membresía? <br> Con la membresía Neuromex podrás tener ventaja de rentar equipo de todas nuestras categorías, además también podrás comprar productos sin costo de envió. <br> Esto te beneficia ya que el costo de algunos productos o proyectos es muy costoso y solo se llega a ocupar solo una vez este material, por lo cual la renta del equipo es mejor ya que podrás utilizar el equipo reduciendo los costos. <br> Con la membresía podrás rentar equipo de las siguientes categorías: <br>

            <br>1 de cada uno de la sección microcontroladores
            <br> 1 de cada uno de la sección microporcesadores(RASPBERRY)
            <br> 2 de cada uno de la sección sensores
            <br> 2 de cada uno de la sección motores
            <br> 1 de cada uno de la sección herramientas
            <br> 2 de cada uno de la sección transmisores
            <br> 20 de cada uno de la sección leds
            <br> 20 de cada uno de la sección componentes
            <br> 2 de cada uno de la sección otros
        </p>
        <a class="cta-btn" href="#">Adquirir membresia</a>
    </div>

</section>