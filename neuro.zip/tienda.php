<div class="row contenido">
    <div class="col-12 infor text-center">
        <h1>Tienda</h1>
    </div>


    <div class="col-12 col-sm-12 col-md-4 col-xl-4 p-5">
        <div class="producto">
            <div class="row">
                <img src="./img/productos/arduinoUno.png" class="card-img-top" alt="">
            </div>
            <div class="row infor text-center justify-content-around">
                <div class="col-12">
                    <h5>Arduino <br>$100.00</h5>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-5">
                    <button class="btn boton-producto ion-ios-cart"></button>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-7">
                    <button class="btn boton-producto">Ver m&aacute;s</button>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-4 col-xl-4 p-5">
        <div class="producto">
            <div class="row">
                <img src="./img/productos/arduinoUno.png" class="card-img-top" alt="">
            </div>
            <div class="row infor text-center justify-content-around">
                <div class="col-12">
                    <h5>Arduino <br>$100.00</h5>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-5">
                    <button class="btn boton-producto ion-ios-cart"></button>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-7">
                    <button class="btn boton-producto">Ver m&aacute;s</button>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-4 col-xl-4 p-5">
        <div class="producto">
            <div class="row">
                <img src="./img/productos/arduinoUno.png" class="card-img-top" alt="">
            </div>
            <div class="row infor text-center justify-content-around">
                <div class="col-12">
                    <h5>Arduino <br>$100.00</h5>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-5">
                    <button class="btn boton-producto ion-ios-cart"></button>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-7">
                    <button class="btn boton-producto">Ver m&aacute;s</button>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-4 col-xl-4 p-5">
        <div class="producto">
            <div class="row">
                <img src="./img/productos/arduinoUno.png" class="card-img-top" alt="">
            </div>
            <div class="row infor text-center justify-content-around">
                <div class="col-12">
                    <h5>Arduino <br>$100.00</h5>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-5">
                    <button class="btn boton-producto ion-ios-cart"></button>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-7">
                    <button class="btn boton-producto">Ver m&aacute;s</button>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-4 col-xl-4 p-5">
        <div class="producto">
            <div class="row">
                <img src="./img/productos/arduinoUno.png" class="card-img-top" alt="">
            </div>
            <div class="row infor text-center justify-content-around">
                <div class="col-12">
                    <h5>Arduino <br>$100.00</h5>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-5">
                    <button class="btn boton-producto ion-ios-cart"></button>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-7">
                    <button class="btn boton-producto">Ver m&aacute;s</button>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-4 col-xl-4 p-5">
        <div class="producto">
            <div class="row">
                <img src="./img/productos/arduinoUno.png" class="card-img-top" alt="">
            </div>
            <div class="row infor text-center justify-content-around">
                <div class="col-12">
                    <h5>Arduino <br>$100.00</h5>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-5">
                    <button class="btn boton-producto ion-ios-cart"></button>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-7">
                    <button class="btn boton-producto">Ver m&aacute;s</button>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-4 col-xl-4 p-5">
        <div class="producto">
            <div class="row">
                <img src="./img/productos/arduinoUno.png" class="card-img-top" alt="">
            </div>
            <div class="row infor text-center justify-content-around">
                <div class="col-12">
                    <h5>Arduino <br>$100.00</h5>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-5">
                    <button class="btn boton-producto ion-ios-cart"></button>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-7">
                    <button class="btn boton-producto">Ver m&aacute;s</button>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-4 col-xl-4 p-5">
        <div class="producto">
            <div class="row">
                <img src="./img/productos/arduinoUno.png" class="card-img-top" alt="">
            </div>
            <div class="row infor text-center justify-content-around">
                <div class="col-12">
                    <h5>Arduino <br>$100.00</h5>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-5">
                    <button class="btn boton-producto ion-ios-cart"></button>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-7">
                    <button class="btn boton-producto">Ver m&aacute;s</button>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-4 col-xl-4 p-5">
        <div class="producto">
            <div class="row">
                <img src="./img/productos/arduinoUno.png" class="card-img-top" alt="">
            </div>
            <div class="row infor text-center justify-content-around">
                <div class="col-12">
                    <h5>Arduino <br>$100.00</h5>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-5">
                    <button class="btn boton-producto ion-ios-cart"></button>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-xl-7">
                    <button class="btn boton-producto">Ver m&aacute;s</button>
                </div>
            </div>
        </div>
    </div>

</div>