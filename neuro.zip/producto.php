<div class="row contenido">
    <div class="col-12 col-sm-12 col-md-6">
        <div class="row p-5">
            <div class="col-12">
                <img src="./img/productos/RASP.png" class="card-img-top" alt="">
            </div>
        </div>
        <div class="row infor text-center">
            <div class="col-12">
                <h2>Raspberry pi 3</h2>
            </div>
            <div class="col-12">
                <h3>$1000.00</h3>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-6 text-center">
        <div class="col-12 infor title">
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptatum veritatis, magnam, provident repellat vitae beatae dolorem iste deserunt numquam, expedita commodi nulla hic enim ratione impedit illum assumenda. Maxime, dolor.</p>
        </div>
        <div class="row">
            <div class="col-12 col-md-6 col-xl-6">
                <input type="number" name="cantidad" id="" min="0">
            </div>
            <div class="col-12 col-md-6 col-xl-6">
                <button class="btn boton-producto">Agregar al carrito</button>
            </div>
        </div>
        
    </div>
</div>